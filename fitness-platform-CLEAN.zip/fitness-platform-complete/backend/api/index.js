const express = require('express');
const cors = require('cors');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const { Pool } = require('pg');

const app = express();
app.use(cors());
app.use(express.json());

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: { rejectUnauthorized: false }
});

const authenticateToken = (req, res, next) => {
  const token = req.headers['authorization']?.split(' ')[1];
  if (!token) return res.status(401).json({ error: 'Access denied' });
  jwt.verify(token, process.env.JWT_SECRET, (err, user) => {
    if (err) return res.status(403).json({ error: 'Invalid token' });
    req.user = user;
    next();
  });
};

const isAdmin = (req, res, next) => {
  if (req.user.role !== 'admin') return res.status(403).json({ error: 'Admin required' });
  next();
};

// Auth
app.post('/api/auth/register', async (req, res) => {
  try {
    const { fullName, email, phone, password } = req.body;
    const exists = await pool.query('SELECT * FROM users WHERE email = $1', [email]);
    if (exists.rows.length > 0) return res.status(400).json({ error: 'Email exists' });
    const hashedPassword = await bcrypt.hash(password, 10);
    const result = await pool.query(
      'INSERT INTO users (full_name, email, phone, password) VALUES ($1, $2, $3, $4) RETURNING *',
      [fullName, email, phone, hashedPassword]
    );
    const user = result.rows[0];
    delete user.password;
    res.json({ user });
  } catch (error) {
    res.status(500).json({ error: 'Registration failed' });
  }
});

app.post('/api/auth/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    const result = await pool.query('SELECT * FROM users WHERE email = $1', [email]);
    if (result.rows.length === 0) return res.status(400).json({ error: 'Invalid credentials' });
    const user = result.rows[0];
    const valid = await bcrypt.compare(password, user.password);
    if (!valid) return res.status(400).json({ error: 'Invalid credentials' });
    const token = jwt.sign({ id: user.id, email: user.email, role: user.role }, process.env.JWT_SECRET, { expiresIn: '7d' });
    delete user.password;
    res.json({ token, user });
  } catch (error) {
    res.status(500).json({ error: 'Login failed' });
  }
});

// User
app.get('/api/user/profile', authenticateToken, async (req, res) => {
  try {
    const result = await pool.query('SELECT * FROM users WHERE id = $1', [req.user.id]);
    const user = result.rows[0];
    delete user.password;
    res.json(user);
  } catch (error) {
    res.status(500).json({ error: 'Failed' });
  }
});

app.put('/api/user/update', authenticateToken, async (req, res) => {
  try {
    const { height, currentWeight, targetWeight, age } = req.body;
    await pool.query(
      'UPDATE users SET height = $1, current_weight = $2, target_weight = $3, age = $4 WHERE id = $5',
      [height, currentWeight, targetWeight, age, req.user.id]
    );
    res.json({ message: 'Updated' });
  } catch (error) {
    res.status(500).json({ error: 'Failed' });
  }
});

// PT Form
app.post('/api/pt-form/submit', authenticateToken, async (req, res) => {
  try {
    const { trainingDays, height, weight, age, profession, supplements, healthIssues, goal, desiredWeight, bodyDescription } = req.body;
    const userResult = await pool.query('SELECT pt_used, pt_total FROM users WHERE id = $1', [req.user.id]);
    if (userResult.rows[0].pt_used >= userResult.rows[0].pt_total) {
      return res.status(400).json({ error: 'PT rights exhausted' });
    }
    await pool.query(
      'INSERT INTO pt_forms (user_id, training_days, height, weight, age, profession, supplements, health_issues, goal, desired_weight, body_description) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)',
      [req.user.id, trainingDays, height, weight, age, profession, supplements, healthIssues, goal, desiredWeight, bodyDescription]
    );
    await pool.query('UPDATE users SET pt_used = pt_used + 1 WHERE id = $1', [req.user.id]);
    res.json({ message: 'Submitted' });
  } catch (error) {
    res.status(500).json({ error: 'Failed' });
  }
});

// Questions
app.post('/api/questions/ask', authenticateToken, async (req, res) => {
  try {
    const { question, image } = req.body;
    const result = await pool.query(
      'INSERT INTO questions (user_id, question, image) VALUES ($1, $2, $3) RETURNING *',
      [req.user.id, question, image]
    );
    res.json({ question: result.rows[0] });
  } catch (error) {
    res.status(500).json({ error: 'Failed' });
  }
});

app.get('/api/questions/my-questions', authenticateToken, async (req, res) => {
  try {
    const result = await pool.query('SELECT * FROM questions WHERE user_id = $1 ORDER BY created_at DESC', [req.user.id]);
    res.json(result.rows);
  } catch (error) {
    res.status(500).json({ error: 'Failed' });
  }
});

// Admin
app.get('/api/admin/users', authenticateToken, isAdmin, async (req, res) => {
  try {
    const result = await pool.query('SELECT id, full_name, email, package_type, pt_used, pt_total FROM users WHERE role = $1', ['member']);
    res.json(result.rows);
  } catch (error) {
    res.status(500).json({ error: 'Failed' });
  }
});

app.get('/api/admin/pt-forms', authenticateToken, isAdmin, async (req, res) => {
  try {
    const result = await pool.query('SELECT pt.*, u.full_name FROM pt_forms pt JOIN users u ON pt.user_id = u.id ORDER BY pt.created_at DESC');
    res.json(result.rows);
  } catch (error) {
    res.status(500).json({ error: 'Failed' });
  }
});

app.post('/api/admin/training-program', authenticateToken, isAdmin, async (req, res) => {
  try {
    const { userId, program } = req.body;
    await pool.query('INSERT INTO training_programs (user_id, program) VALUES ($1, $2)', [userId, JSON.stringify(program)]);
    res.json({ message: 'Created' });
  } catch (error) {
    res.status(500).json({ error: 'Failed' });
  }
});

app.post('/api/admin/nutrition-program', authenticateToken, isAdmin, async (req, res) => {
  try {
    const { userId, meals, alternatives } = req.body;
    await pool.query('INSERT INTO nutrition_programs (user_id, meals, alternatives) VALUES ($1, $2, $3)', [userId, JSON.stringify(meals), JSON.stringify(alternatives)]);
    res.json({ message: 'Created' });
  } catch (error) {
    res.status(500).json({ error: 'Failed' });
  }
});

app.put('/api/admin/questions/:id/answer', authenticateToken, isAdmin, async (req, res) => {
  try {
    const { answer } = req.body;
    await pool.query('UPDATE questions SET answer = $1, status = $2 WHERE id = $3', [answer, 'answered', req.params.id]);
    res.json({ message: 'Answered' });
  } catch (error) {
    res.status(500).json({ error: 'Failed' });
  }
});

app.get('/api/admin/questions', authenticateToken, isAdmin, async (req, res) => {
  try {
    const result = await pool.query('SELECT q.*, u.full_name FROM questions q JOIN users u ON q.user_id = u.id ORDER BY q.created_at DESC');
    res.json(result.rows);
  } catch (error) {
    res.status(500).json({ error: 'Failed' });
  }
});

module.exports = app;

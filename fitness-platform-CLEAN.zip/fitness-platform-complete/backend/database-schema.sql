CREATE TABLE users (
    id SERIAL PRIMARY KEY,
    full_name VARCHAR(255) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    phone VARCHAR(20),
    password VARCHAR(255) NOT NULL,
    role VARCHAR(20) DEFAULT 'member',
    has_package BOOLEAN DEFAULT FALSE,
    package_type VARCHAR(50),
    pt_used INTEGER DEFAULT 0,
    pt_total INTEGER DEFAULT 0,
    height INTEGER,
    start_weight DECIMAL(5,2),
    current_weight DECIMAL(5,2),
    target_weight DECIMAL(5,2),
    age INTEGER,
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE pt_forms (
    id SERIAL PRIMARY KEY,
    user_id INTEGER REFERENCES users(id),
    training_days INTEGER,
    height INTEGER,
    weight DECIMAL(5,2),
    age INTEGER,
    profession VARCHAR(255),
    supplements TEXT,
    health_issues TEXT,
    goal VARCHAR(100),
    desired_weight DECIMAL(5,2),
    body_description TEXT,
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE training_programs (
    id SERIAL PRIMARY KEY,
    user_id INTEGER REFERENCES users(id),
    program JSONB,
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE nutrition_programs (
    id SERIAL PRIMARY KEY,
    user_id INTEGER REFERENCES users(id),
    meals JSONB,
    alternatives JSONB,
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE questions (
    id SERIAL PRIMARY KEY,
    user_id INTEGER REFERENCES users(id),
    question TEXT NOT NULL,
    image TEXT,
    answer TEXT,
    status VARCHAR(20) DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT NOW()
);

INSERT INTO users (full_name, email, password, role) 
VALUES ('Admin', 'admin@admin.com', '$2b$10$rKz8VQ7YvxJQZQX5x5X5x5X5x5X5x5X5x5X5x5X5x5X5x5X5x5', 'admin');

const API_URL = 'https://YOUR-BACKEND.vercel.app/api';

const API = {
  async call(endpoint, options = {}) {
    const token = localStorage.getItem('token');
    const res = await fetch(API_URL + endpoint, {
      ...options,
      headers: {
        'Content-Type': 'application/json',
        ...(token && { Authorization: `Bearer ${token}` }),
        ...options.headers
      }
    });
    return res.json();
  },
  
  login: (email, password) => API.call('/auth/login', {
    method: 'POST',
    body: JSON.stringify({ email, password })
  }),
  
  register: (data) => API.call('/auth/register', {
    method: 'POST',
    body: JSON.stringify(data)
  }),
  
  updateProfile: (data) => API.call('/user/update', {
    method: 'PUT',
    body: JSON.stringify(data)
  })
};

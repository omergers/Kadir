// Simple client-side auth/session helpers (demo)
// Stores users in localStorage: ky_users (array), current session in ky_session (email)

(function(){
  function loadUsers(){ try { return JSON.parse(localStorage.getItem('ky_users')||'[]'); } catch(e){ return []; } }
  function saveUsers(users){ localStorage.setItem('ky_users', JSON.stringify(users)); }
  function getSessionEmail(){ return (localStorage.getItem('ky_session')||'').toLowerCase(); }
  function setSessionEmail(email){ localStorage.setItem('ky_session', (email||'').toLowerCase()); }
  function clearSession(){ localStorage.removeItem('ky_session'); }

  function getCurrentUser(){
    const email = getSessionEmail();
    if(!email) return null;
    const users = loadUsers();
    return users.find(u => (u.email||'').toLowerCase() === email) || null;
  }

  function requireLogin(redirectTo){
    const u = getCurrentUser();
    if(!u){
      const to = redirectTo || location.pathname.split('/').pop() || 'index.html';
      location.href = 'member-login.html?next=' + encodeURIComponent(to);
      return null;
    }
    return u;
  }

  
  function requireMembership(redirectTo){
    const u = requireLogin(redirectTo);
    if(!u) return null;
    if(!u.hasPackage){
      location.href = 'package-selection.html';
      return null;
    }
    return u;
  }

  function logout(){
    clearSession();
    location.href = 'index.html';
  }

  function upsertUser(partial){
    const users = loadUsers();
    const email = (partial.email||'').toLowerCase();
    const idx = users.findIndex(u => (u.email||'').toLowerCase() === email);
    if(idx>=0) users[idx] = {...users[idx], ...partial};
    else users.push(partial);
    saveUsers(users);
    return partial;
  }

  window.KYAuth = { loadUsers, saveUsers, getSessionEmail, setSessionEmail, clearSession, getCurrentUser, requireLogin, logout, upsertUser };
})();

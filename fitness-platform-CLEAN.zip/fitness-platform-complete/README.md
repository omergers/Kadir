# 🏋️ Fitness Coaching Platform

## 🚀 Quick Deploy

### 1. Supabase (Database)
1. Create project at supabase.com
2. Run `backend/database-schema.sql` in SQL Editor
3. Copy connection string

### 2. Vercel Backend
1. Push to GitHub
2. Import to Vercel
3. Root Directory: `backend`
4. Add env vars:
   - `DATABASE_URL` (from Supabase)
   - `JWT_SECRET` (any random string)
5. Deploy

### 3. Vercel Frontend  
1. New project (same repo)
2. Root Directory: `frontend`
3. Update `api-config.js` with backend URL
4. Deploy

Done! 🎉
